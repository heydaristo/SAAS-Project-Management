<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AdminUser extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        \App\Models\User::create([
            'id_role' => 1,
            'fullname' => 'Super Admin',
            'email' => 'admin@gmail.com',
            'password' => bcrypt('admin'),
            'profession' => 'Super Admin',
            'experience_level' => 1,
            'organization' => 'Super Admin',
            'photo_profile' => 'Super Admin',
        ]);
    }
}