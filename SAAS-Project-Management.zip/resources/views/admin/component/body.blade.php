<div class="page-body">
    <div class="container-xl">
    @yield('adminbody')
    </div>
  </div>