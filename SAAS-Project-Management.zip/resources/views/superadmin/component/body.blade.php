<div class="page-body">
    <div class="container-xl">
    @yield('superadminbody')
    </div>
  </div>