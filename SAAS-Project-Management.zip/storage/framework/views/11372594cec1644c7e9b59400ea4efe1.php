<?php
  $title= "Invoice";
?>


<?php $__env->startSection('body'); ?> 
<div class="row row-deck row-cards">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Invoice</h3>
      </div>
    
      <div class="card-body border-bottom py-3">
        <div class="d-flex">
          <div class="text-muted">
            <select class="form-select" aria-label="Default select example">
              <option selected>Select Plan</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="text-muted ms-3">
            <select class="form-select" aria-label="Default select example">
              <option selected>Select Plan</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="ms-auto me-3">
            <select class="form-select" id="select">
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="20">20</option>
              <option value="50">50</option>
              <!-- Tambahkan opsi lain sesuai kebutuhan -->
          </select>
        </div>
        <button type="button" class="btn btn-primary font-weight-bolder" data-bs-toggle="modal"
        data-bs-target="#tambah_invoice">
        New Project
        </button>
        </div>
      </div>  
    <div class="table-responsive">
      <table class="table card-table table-vcenter text-nowrap datatable">
        <thead>
          <tr>
            <th class="w-1">No.
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-sm icon-thick" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 15l6 -6l6 6" /></svg>
            </th>
            <th>Project Name</th>
            <th>Freelancer</th>
            <th>Tanggal buat</th>
            <th>Status</th>
            <th>Kadarluarsa</th>
            <th>Total</th>
            <th class="w-1"></th>
          </tr>
        </thead>
        <tbody>
            <?php
            $i = 1 + (($invoices->currentPage()-1) * $invoices->perPage());
            ?>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><span class="text-muted"><?php echo e($i++); ?></span></td>
              <td><?php echo e($invoice->project_name); ?></td>
              <td><?php echo e($invoice->name); ?></td>
              <td><?php echo e($invoice->issued_date); ?></td>
              <td>
                <?php if($invoice->status == 'Active'): ?>
                    <span class="badge text-bg-success"><?php echo e($invoice->status); ?></span>
                <?php elseif($invoice->status == 'Pending'): ?>
                    <span class="badge text-bg-warning"><?php echo e($invoice->status); ?></span>
                <?php elseif($invoice->status == 'Inactive'): ?>
                    <span class="badge text-bg-danger"><?php echo e($invoice->status); ?></span>
                <?php endif; ?>
            </td>
              <td><?php echo e($invoice->due_date); ?></td>
              <td><?php echo e($invoice->total); ?></td>

            <td><div class="btn-group mb-1 dropleft ">
              <div class="dropdown dropleft">
                <button class="btn btn-primary dropdown-toggle me-1" type="button" id="dropdownMenuButtonIcon" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Aksi
                </button>
                <div class="dropdown-menu dropdown-menu-end">
                  <button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modalEdit-<?php echo e($invoice->id); ?>">
                    Edit
                  </button>
                  <button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modalDelete-<?php echo e($invoice->id); ?>">Delete</button>
                </div>
              </div>
          </div></td>
          </tr>

          
          <div class="modal fade" id="modalEdit-<?php echo e($invoice->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modal2Label">Edit Invoice</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form action="<?php echo e(route('workspace.invoices.update', ['id' => $invoice->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                      <label for="Project">Project Name</label>
                      <select class="form-control mt-1" name="id_project" id="user_id">
                        <option value="">Select Project</option>
                        <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectmodels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($projectmodels->id); ?>" <?php echo e($invoice->id_project == $projectmodels->id ? 'selected' : ''); ?>>
                          <?php echo e($projectmodels->project_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                     </div>
                   <div class="mb-3">
                      <label for="client">Client Name</label>
                      <select class="form-control mt-1" name="id_client" id="id_client">
                        <option value="">Select client</option>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($client->id); ?>" <?php echo e($invoice->id_client == $client->id ? 'selected' : ''); ?>>
                          <?php echo e($client->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                     </div>
                    <div class="mb-3">
                      <label for="status">Status</label>
                      <select class="form-control mt-1" name="status">
                        <option value="Active" <?php echo e($invoice->status == 'Active' ? 'selected' : ''); ?>>Active</option>
                        <option value="Pending" <?php echo e($invoice->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="Inactive" <?php echo e($invoice->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                     </div>
                    <div class="mb-3">
                      <label for="due_date">Expired</label>
                      <input type="date" class="form-control mt-1" value="<?php echo e($invoice->due_date); ?>" id="due_date" name="due_date" placeholder="Masukkan alamat" required />
                     </div>
                     <div class="mb-3">
                      <label for="total">Total</label>
                      <input type="number" class="form-control mt-1" value="<?php echo e($invoice->total); ?>" id="total" name="total" placeholder="Masukkan total" required />
                     </div>
                
                </div>
                <div class="modal-footer">
                  <a type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
                  <button type="submit" class="btn btn-primary">Edit Project</button>
                </div>
              </form>
              </div>
            </div>
          </div>
          



          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
    <div class="card-footer d-flex align-items-center ms-auto">
      <?php echo $invoices->appends(Request::except('page'))->links('pagination::bootstrap-5'); ?>

    </div>
  </div>
</div>
</div>


<div class="modal fade" id="tambah_invoice" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal2Label">Add Invoice</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('workspace.invoices.store')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="Project">Project Name</label>
            <select class="form-control mt-1" name="id_project" id="user_id">
              <option value="">Select Project</option>
              <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectmodels): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($projectmodels->id); ?>"><?php echo e($projectmodels->project_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
           </div>
         <div class="mb-3">
            <label for="client">Client Name</label>
            <select class="form-control mt-1" name="id_client" id="id_client">
              <option value="">Select client</option>
              <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
           </div>
          <div class="mb-3">
            <label for="status">Status</label>
            <select class="form-control mt-1" name="status">
              <option value="">Select Status</option>
              <option value="Active">Active</option>
              <option value="Pending">Pending</option>
              <option value="Inactive">Inactive</option>
          </select>
           </div>
          <div class="mb-3">
            <label for="due_date">Expired</label>
            <input type="date" class="form-control mt-1" id="due_date" name="due_date" placeholder="Masukkan alamat" required />
           </div>
           <div class="mb-3">
            <label for="total">Total</label>
            <input type="number" class="form-control mt-1" id="total" name="total" placeholder="Masukkan total" required />
           </div>
      
      </div>
      <div class="modal-footer">
        <a type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
        <button type="submit" class="btn btn-primary">Add Project</button>
      </div>
    </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweetalert'); ?>
<script>
    // Auto-close the alert messages after 3 seconds (3000 milliseconds)
    setTimeout(function() {
        $('.swal2-popup').fadeOut();
    }, 3000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SAAS-Project-Management\resources\views/workspace/invoice/index.blade.php ENDPATH**/ ?>