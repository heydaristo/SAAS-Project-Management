<footer class="footer footer-transparent d-print-none">
  <div class="container-xl">
    <div class="row text-center align-items-center flex-row-reverse">
      <ul class="list-inline list-inline-dots mb-0">
        <li class="list-inline-item">
          Copyright &copy; 2023
          <a href="." class="link-secondary">Tabler</a>.
          All rights reserved.
        </li>
        <li class="list-inline-item">
          <a href="./changelog.html" class="link-secondary" rel="noopener">
            v1.0.0-beta19
          </a>
        </li>
      </ul>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\SAAS-Project-Management\resources\views/workspace/component/footer.blade.php ENDPATH**/ ?>