<?php $__env->startSection('body'); ?>

<div class="col-md">
    <div class="card">
        
        <div class="card-header">
            <h4>Please Choose A new Password</h4>
        </div>
        <div class="card-body">

            <form action="<?php echo e(route('workspace.settings.password')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group row mb-0 ">
                    <label for="oldpassword" class="col-md-4 col-form-label text-md-right mt-3">Old Password</label>
                    <div class="col-md-6 mt-3">
                        <input type="password" id="oldpassword" class="form-control" name="oldPassword" required>
                    </div>

                    <label for="newpassword" class="col-md-4 col-form-label text-md-right mt-3">New Password</label>
                    <div class="col-md-6 mt-3">
                        <input type="password" id="newpassword" class="form-control" name="newPassword" required>
                    </div>

                    <label for="confirmpassword" class="col-md-4 col-form-label text-md-right mt-3">Confirm Password</label>
                    <div class="col-md-6 mt-3">
                        <input type="password" id="confirmpassword" class="form-control" name="confirmPassword" required>
                    </div>      
                </div>
                <div class="form-group row mb-0 mt-3">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Change Password
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SAAS-Project-Management\resources\views/workspace/changepassword.blade.php ENDPATH**/ ?>