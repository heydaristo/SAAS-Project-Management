<div class="page-body">
    <div class="container-xl">
    <?php echo $__env->yieldContent('body'); ?>
    
    </div>
  </div><?php /**PATH C:\xampp\htdocs\SAAS-Project-Management\resources\views/workspace/component/body.blade.php ENDPATH**/ ?>