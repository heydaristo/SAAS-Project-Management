<div class="page-body">
    <div class="container-xl">
    <?php echo $__env->yieldContent('superadminbody'); ?>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\SAAS-Project-Management\resources\views/superadmin/component/body.blade.php ENDPATH**/ ?>