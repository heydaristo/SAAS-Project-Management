<?php
  $title= "Project";
?>


<?php $__env->startSection('body'); ?> 
<div class="row row-deck row-cards">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Project</h3>
      </div>
    
      <div class="card-body border-bottom py-3">
        <div class="d-flex">
          <div class="text-muted">
            <select class="form-select" aria-label="Default select example">
              <option selected>Select Plan</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="text-muted ms-3">
            <select class="form-select" aria-label="Default select example">
              <option selected>Select Plan</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="ms-auto me-3">
            <select class="form-select" id="select">
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="20">20</option>
              <option value="50">50</option>
              <!-- Tambahkan opsi lain sesuai kebutuhan -->
          </select>
        </div>
        <button type="button" class="btn btn-primary font-weight-bolder" data-bs-toggle="modal"
        data-bs-target="#tambah_project">
        New Project
        </button>
        </div>
      </div>  
    <div class="table-responsive">
      <table class="table card-table table-vcenter text-nowrap datatable">
        <thead>
          <tr>
            <th class="w-1">No.
              <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-sm icon-thick" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 15l6 -6l6 6" /></svg>
            </th>
            <th>Project Name</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Status</th>
            <th>Client</th>
            
            <th class="w-1"></th>
          </tr>
        </thead>
        <tbody>
            <?php
            $i = 1 + (($projectmodels->currentPage()-1) * $projectmodels->perPage());
            ?>
            <?php $__currentLoopData = $projectmodels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><span class="text-muted"><?php echo e($i++); ?></span></td>
              <td><?php echo e($project->project_name); ?></td>
              <td><?php echo e($project->start_date); ?></td>
              <td><?php echo e($project->end_date); ?></td>
              <td>
                <?php if($project->status == 'Active'): ?>
                    <span class="badge text-bg-success"><?php echo e($project->status); ?></span>
                <?php elseif($project->status == 'Pending'): ?>
                    <span class="badge text-bg-warning"><?php echo e($project->status); ?></span>
                <?php elseif($project->status == 'Inactive'): ?>
                    <span class="badge text-bg-danger"><?php echo e($project->status); ?></span>
                <?php endif; ?>
            </td>
              <td><?php echo e($project->name); ?></td>
              
            <td><div class="btn-group mb-1 dropleft ">
              <div class="dropdown dropleft">
                <button class="btn btn-primary dropdown-toggle me-1" type="button" id="dropdownMenuButtonIcon" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Aksi
                </button>
                <div class="dropdown-menu dropdown-menu-end">
                  <button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modalEdit-<?php echo e($project->id); ?>">
                    Edit
                  </button>
                  <button class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modalDelete-<?php echo e($project->id); ?>">Delete</button>
                </div>
              </div>
          </div></td>
          </tr>

          
          <div class="modal fade" id="modalEdit-<?php echo e($project->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modal2Label">Project Name</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form action="<?php echo e(route('workspace.projects.update', ['id' => $project->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                      <label for="project_name">Project Name</label>
                      <input type="text" value="<?php echo e($project->project_name); ?>" class="form-control mt-1" name="project_name" placeholder="Masukkan Project name" required />
                    </div>
                    <div class="mb-3">
                     <label for="start_date">Start Date</label>
                     <input type="date" class="form-control mt-1" value="<?php echo e($project->start_date); ?>" id="start_date" name="start_date" placeholder="Start Date" required />
                    </div>
                    <div class="mb-3">
                      <label for="end_date">End Date</label>
                      <input type="date" class="form-control mt-1" value="<?php echo e($project->end_date); ?>" id="end_date" name="end_date" placeholder="Masukkan alamat" required />
                     </div>
                    <div class="mb-3">
                      <label for="status">Status</label>
                      <select class="form-control mt-1" name="status">
                          <option value="Active" <?php echo e($project->status == 'Active' ? 'selected' : ''); ?>>Active</option>
                          <option value="Pending" <?php echo e($project->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                          <option value="Inactive" <?php echo e($project->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                      </select>
                     </div>
                     <div class="mb-3">
                      <label for="client">Nama Client</label>
                      <select class="form-control mt-1" name="id_client" id="id_client">
                          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($client->user_id == auth()->user()->id): ?>
                                  <option value="<?php echo e($client->id); ?>" <?php echo e($project->id_client == $client->id ? 'selected' : ''); ?>>
                                      <?php echo e($client->name); ?>

                                  </option>
                              <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </div>
                     
                </div>
                <div class="modal-footer">
                  <a type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
                  <button type="submit" class="btn btn-primary">Add Project</button>
                </div>
              </form>
              </div>
            </div>
          </div>


<div class="modal modal-blur fade" id="modalDelete-<?php echo e($project->id); ?>" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          <div class="modal-status bg-danger"></div>
          <div class="modal-body text-center py-4">
              <svg xmlns="http://www.w3.org/2000/svg" class="icon mb-2 text-danger icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                  <path d="M12 9v4"></path>
                  <path d="M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636 -2.87l-8.106 -13.536a1.914 1.914 0 0 0 -3.274 0z"></path>
                  <path d="M12 16h.01"></path>
              </svg>
              <h3>Are you sure?</h3>
              <div class="text-secondary">Do you really want to remove project <?php echo e($project->project_name); ?>? What you've done cannot be undone.</div>
          </div>
          <div class="modal-footer">
              <div class="w-100">
                  <div class="row">
                      <form action="<?php echo e(route('workspace.projects.delete',['id' => $project->id])); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <div class="col">
                              <a href="#" class="btn w-100" data-bs-dismiss="modal">Cancel</a>
                          </div>
                          <div class="col">
                              <button class="btn btn-danger w-100" data-bs-dismiss="modal">Delete</button>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
    </div>
    <div class="card-footer d-flex align-items-center ms-auto">
      <?php echo $projectmodels->appends(Request::except('page'))->links('pagination::bootstrap-5'); ?>

    </div>
  </div>
</div>
</div>


<div class="modal fade" id="tambah_project" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal2Label">Project Name</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('workspace.projects.store')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label for="project_name">Project Name</label>
            <input type="text" class="form-control mt-1" name="project_name" placeholder="Masukkan Project name" required />
          </div>
          <div class="mb-3">
           <label for="start_date">Start Date</label>
           <input type="date" class="form-control mt-1" id="start_date" name="start_date" placeholder="Start Date" required />
          </div>
          <div class="mb-3">
            <label for="end_date">End Date</label>
            <input type="date" class="form-control mt-1" id="end_date" name="end_date" placeholder="Masukkan alamat" required />
           </div>
          <div class="mb-3">
            <label for="status">Status</label>
            <select class="form-control mt-1" name="status">
              <option value="">Select Status</option>
              <option value="Active">Active</option>
              <option value="Pending">Pending</option>
              <option value="Inactive">Inactive</option>
          </select>
           </div>
           <div class="mb-3">
            <label for="client">Nama Client</label>
            <select class="form-control mt-1" name="id_client" id="id_client">
              <option value="">Select client</option>
              <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
           </div>
           
      </div>
      <div class="modal-footer">
        <a type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
        <button type="submit" class="btn btn-primary">Add Project</button>
      </div>
    </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweetalert'); ?>
<script>
    // Auto-close the alert messages after 3 seconds (3000 milliseconds)
    setTimeout(function() {
        $('.swal2-popup').fadeOut();
    }, 3000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SAAS-Project-Management\resources\views/workspace/projects/index.blade.php ENDPATH**/ ?>